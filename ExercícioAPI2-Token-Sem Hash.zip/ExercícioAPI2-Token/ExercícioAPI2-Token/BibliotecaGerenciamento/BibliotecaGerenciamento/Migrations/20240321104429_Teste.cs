﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BibliotecaGerenciamento.Migrations
{
    /// <inheritdoc />
    public partial class Teste : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Livros_Editoras_EditoraModelId",
                table: "Livros");

            migrationBuilder.DropIndex(
                name: "IX_Livros_EditoraModelId",
                table: "Livros");

            migrationBuilder.DropColumn(
                name: "EditoraModelId",
                table: "Livros");

            migrationBuilder.AddColumn<string>(
                name: "Livros",
                table: "Editoras",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Livros",
                table: "Editoras");

            migrationBuilder.AddColumn<int>(
                name: "EditoraModelId",
                table: "Livros",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Livros_EditoraModelId",
                table: "Livros",
                column: "EditoraModelId");

            migrationBuilder.AddForeignKey(
                name: "FK_Livros_Editoras_EditoraModelId",
                table: "Livros",
                column: "EditoraModelId",
                principalTable: "Editoras",
                principalColumn: "Id");
        }
    }
}
