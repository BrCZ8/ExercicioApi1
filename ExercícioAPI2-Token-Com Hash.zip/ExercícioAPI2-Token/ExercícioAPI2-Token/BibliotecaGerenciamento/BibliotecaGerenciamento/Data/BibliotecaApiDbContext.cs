﻿using BibliotecaGerenciamento.Data.Map;
using BibliotecaGerenciamento.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Hosting;
using System.Text.Json;

namespace BibliotecaGerenciamento.Data
{
    public class BibliotecaApiDbContext : DbContext
    {
        public BibliotecaApiDbContext(DbContextOptions<BibliotecaApiDbContext> options) : base(options) 
        { }

        public DbSet<LivroModel> Livros { get; set; }
        public DbSet<AutorModel> Autores { get; set; }
        public DbSet<EditoraModel> Editoras { get; set; }
        public DbSet<UsuarioModel> Usuarios { get; set; }
        public DbSet<EmprestimoModel> Emprestimos { get; set; }
        public DbSet<ReservaModel> Reservas { get; set; }
        public DbSet<AvaliacaoModel> Avaliacoes { get; set; }
        public DbSet<LoginModel> Login { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new LivroMap());
            modelBuilder.ApplyConfiguration(new AutorMap());
            modelBuilder.ApplyConfiguration(new EditoraMap());
            modelBuilder.ApplyConfiguration(new UsuarioMap());
            modelBuilder.ApplyConfiguration(new EmprestimoMap());
            modelBuilder.ApplyConfiguration(new ReservaMap());
            modelBuilder.ApplyConfiguration(new AvaliacaoMap());


            modelBuilder.Entity<EditoraModel>()
            .Property(e => e.Livros)
            .HasConversion(
        v => JsonSerializer.Serialize(v, (JsonSerializerOptions)null),
        v => JsonSerializer.Deserialize<List<LivroModel>>(v, (JsonSerializerOptions)null),
        new ValueComparer<ICollection<LivroModel>>(
            (c1, c2) => c1.SequenceEqual(c2),
            c => c.Aggregate(0, (a, v) => HashCode.Combine(a, v.GetHashCode())),
            c => (ICollection<LivroModel>)c.ToList()));
        }
    }
}
