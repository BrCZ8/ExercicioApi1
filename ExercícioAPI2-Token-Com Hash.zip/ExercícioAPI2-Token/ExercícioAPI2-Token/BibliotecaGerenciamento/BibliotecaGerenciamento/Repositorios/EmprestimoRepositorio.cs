﻿using BibliotecaGerenciamento.Data;
using BibliotecaGerenciamento.Models;
using BibliotecaGerenciamento.Repositorios.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace BibliotecaGerenciamento.Repositorios
{
    public class EmprestimoRepositorio : IEmprestimoRepositorio
    {
        private readonly BibliotecaApiDbContext _dbContext;

        public EmprestimoRepositorio(BibliotecaApiDbContext bibliotecaApiDbContext)
        {
            _dbContext = bibliotecaApiDbContext;
        }

        public async Task<EmprestimoModel> BuscarPorId(int id)
        {
            return await _dbContext.Emprestimos
                .Include(y => y.Livro)
                .Include(z => z.Usuario)
                .FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<EmprestimoModel>> BuscarTodosEmprestimos()
        {
            return await _dbContext.Emprestimos
                .Include (y => y.Livro)
                .Include (z => z.Usuario)
                .ToListAsync();
        }
        public async Task<EmprestimoModel> Adicionar(EmprestimoModel emprestimo)
        {
            await _dbContext.Emprestimos.AddAsync(emprestimo);
            await _dbContext.SaveChangesAsync();

            return emprestimo;
        }

        public async Task<bool> Apagar(int id)
        {
            EmprestimoModel emprestimoPorId = await BuscarPorId(id);
            if (emprestimoPorId == null)
            {
                throw new Exception($"Empréstimo do Id: {id} não foi encontrado.");
            }

            _dbContext.Emprestimos.Remove(emprestimoPorId);
            await _dbContext.SaveChangesAsync();

            return true;
        }

        public async Task<EmprestimoModel> Atualizar(EmprestimoModel emprestimo, int id)
        {
            EmprestimoModel emprestimoPorId = await BuscarPorId(id);
            if (emprestimoPorId == null)
            {
                throw new Exception($"Empréstimo do Id: {id} não foi encontrado.");
            }

            emprestimoPorId.DataEmprestimo = emprestimoPorId.DataEmprestimo;
            emprestimoPorId.DataDevolucao = emprestimoPorId.DataDevolucao;
            emprestimoPorId.Status = emprestimoPorId.Status;
            emprestimoPorId.LivroId = emprestimoPorId.LivroId;
            emprestimoPorId.UsuarioId = emprestimoPorId.UsuarioId;

            _dbContext.Emprestimos.Update(emprestimoPorId);
            await _dbContext.SaveChangesAsync();
            return emprestimoPorId;
        }
    }
}
