﻿namespace BibliotecaGerenciamento.Models
{
    public class LoginModel
    {
        public int Id { get; set; }
        public string? Login { get; set; }
        public string? Senha { get; set; }
    }
}
