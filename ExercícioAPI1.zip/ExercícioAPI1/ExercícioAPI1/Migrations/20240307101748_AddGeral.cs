﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ExercícioAPI1.Migrations
{
    /// <inheritdoc />
    public partial class AddGeral : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
