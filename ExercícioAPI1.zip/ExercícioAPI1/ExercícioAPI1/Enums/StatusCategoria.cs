﻿using System.ComponentModel;

namespace ExercícioAPI1.Enums
{
    public enum StatusCategoria
    {
        [Description("Ativo")]
        Ativo = 1,
        [Description("Inativo")]
        Inativo = 2
    }
}
